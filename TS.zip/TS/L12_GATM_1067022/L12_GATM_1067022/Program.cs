﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_GATM_1067022
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] num = new int[14];
            //valores
            num[0]=4;
            num[1]=5;
            num[2]=8;
            num[3]=-5;
            num[4]=7;
            num[5]=25;
            num[6]=-1;
            num[7]=18;
            num[8]=1;
            num[9]=-7;
            num[10]=-2;
            num[11]=6;
            num[12]=-4;
            num[13]=10;
            //suma
            int suma = num.Sum();
            Console.WriteLine("La suma de los elementos es: "+suma);
            //valor dado
            Console.WriteLine("Escribe un valor:");
            int valor = int.Parse(Console.ReadLine());

            //Encima de valor
            int contador1 = 0;
            for (int i = 0; i<14; i++)
            {
                if (num[i]>valor)
                {
                    contador1++;
                }
            }
            Console.WriteLine(contador1+" valores estan por encima del valor");
            //porcentaje por encima de valor
            int porcentaje = (contador1*100)/14;
            Console.WriteLine("El porcentaje de valores por encima del valor es de: "+porcentaje);






            Console.ReadKey();
        }
    }
    
}
