﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace L11_GATM_1067022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int N = 0;
            Console.WriteLine("Ingresa el numero de posiciones del vector");
            N=int.Parse(Console.ReadLine());

            int[] enteros = new int[N];

            Console.WriteLine("Vector con "+N+" posiciones");
                       

            for (int i = 0; i<N; i++)
            {
                Console.WriteLine("Ingrese un número ");
                enteros[i]=int.Parse(Console.ReadLine());

            }

            for (int i = 0; i<N; i++)
            {
                Console.WriteLine("N"+(i+1));
                Console.WriteLine(enteros[i]);
            }

            int suma = enteros.Sum();
            Console.WriteLine("La suma se los elementos es: "+suma);

            int sumap = 0;
            int sumai = 0;
            for (int i = 0; i<N; i++)
            {
               if (i%2==0)
                {
                    sumap=sumap +enteros[i];
                }
               else
                {
                    sumai=sumai+enteros[i];
                }

            }
            Console.WriteLine("La suma de las casillas pares es "+sumai);
            Console.WriteLine("La suma de las casillas impares es "+sumap);


            Console.ReadKey();
        }
    }
}
