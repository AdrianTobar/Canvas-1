﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TareaProblema1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variables
            Console.WriteLine("TareaTrianguloRectangulo");
            Console.WriteLine("Ingrese el valor del primer cateto:");
            double catetoIngresado = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor del segundo cateto:");
            double cateto2Ingresado = double.Parse(Console.ReadLine());

            double perimetroCalculado = 0;
            double areaCalculada = 0;
            double hipotenusaCalculada = 0;
            double angulotetaCalculado = 0;
            double anguloalfaCalculado = 0;

            //objeto tipo circulo
            Triangulo objTriangulo = new Triangulo(catetoIngresado, cateto2Ingresado);
           
            //guardar valores
            objTriangulo.CalcularGeometría(ref perimetroCalculado, ref areaCalculada, ref hipotenusaCalculada, ref anguloalfaCalculado, ref angulotetaCalculado);

            Console.WriteLine("Perímetro:"+perimetroCalculado);
            Console.WriteLine("Área:"+areaCalculada);
            Console.WriteLine("Hipotenusa:"+hipotenusaCalculada);
            Console.WriteLine("Angulo Teta:"+angulotetaCalculado);
            Console.WriteLine("Angulo Alfa:"+anguloalfaCalculado);

            Console.ReadKey();



        }
    }
    class Triangulo
    {
        private double cateto;
        private double cateto2;
        public Triangulo(double Cateto, double Cateto2)
                    {
            cateto = Cateto;
            cateto2 = Cateto2;
        }
       
        private double ObtenerPerimetro()
        {
            double perimetro = Math.Sqrt(Math.Pow(cateto,2)+Math.Pow(cateto2,2))+cateto+cateto2;
            return perimetro;
        }
        private double ObtenerArea()
        {
            double area = (cateto*cateto2)/2;
            return area;

        }

        private double ObtenerHipotenusa()
        {
            double hipotenusa = Math.Sqrt(Math.Pow(cateto, 2)+Math.Pow(cateto2, 2));
            return hipotenusa;
        }

        private double ObtenerAnguloteta()
        {
            double Anguloteta = (Math.Atan(cateto/cateto2))*(180/Math.PI);
            return Anguloteta;
        }
        private double ObtenerAnguloalfa()
        {
            double Anguloalfa = 180-90-((Math.Atan(cateto/cateto2))*(180/Math.PI));
            return Anguloalfa;
        }


        public void CalcularGeometría(ref double unPerimetro, ref double unArea, ref double unaHipotenusa, ref double unAnguloteta, ref double unAnguloalfa)
        {
            unPerimetro=ObtenerPerimetro();
            unArea=ObtenerArea();
            unaHipotenusa=ObtenerHipotenusa();
            unAnguloteta=ObtenerAnguloteta();
            unAnguloalfa=ObtenerAnguloalfa();

        }


    }
}
