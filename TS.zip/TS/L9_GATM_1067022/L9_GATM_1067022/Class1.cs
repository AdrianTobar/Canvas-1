﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace L9_GATM_1067022
{
    internal class Automovil
    {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double TipoDeCambioDolar;
        private double DescuentoAplicado;

        public Automovil()
        {
            this.modelo=2019;
            this.precio=10000;
            this.marca="";
            this.disponible=false;
            this.TipoDeCambioDolar=7.5;
            this.DescuentoAplicado=0;

        }
        public void DefinirModelo(int unModelo)
        {
            this.modelo=unModelo;
        }
        public void DefinirPrecio(double unPrecio)
        {
            this.precio=unPrecio;
        }
        public void DefinirMarca(string unaMarca)
        {
            this.marca=unaMarca;
        }
        public void Cambiardisponibilidad()
        {
            if (this.disponible==true)
            {
                this.disponible=false;
            }
            else
            {
                this.disponible=true;
            }
        }
        public string MostrarDisponibilidad()
        {
            string res;
            if (this.disponible==true)
            {
                res ="Disponible";
                
            }
            else
            {
                res="No se encuentra disponible actualmente";
                
            }
            return res;

        }
            
        public void DefinirTipoDeCambioDolar(double unTipoDeCambioDolar)
        {
            this.TipoDeCambioDolar=unTipoDeCambioDolar;
        }
        public void aplicarDescuento(double miDescuento)
        {
            this.DescuentoAplicado=miDescuento;
            double precio =(this.precio)- ((this.precio)*miDescuento);
            this.DefinirPrecio(precio);

        }

        public void mostrarInformacíon()
        {
            Console.WriteLine("Marca: "+this.marca);
            Console.WriteLine("Modelo: "+this.modelo);
            Console.WriteLine("Precio de venta: Q"+this.precio+" Equivalente a" +(this.precio/7.8)+"$");
            Console.WriteLine(this.disponible);
        }

        

    }
}

